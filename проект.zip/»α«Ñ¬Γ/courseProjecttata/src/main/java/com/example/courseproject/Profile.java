package com.example.courseproject;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.Objects;
import java.util.ResourceBundle;

public class Profile implements Initializable{
    @FXML
    private ImageView photo;
    @FXML
    private Text textHi;
    @FXML
    private Text doljnost;
    @FXML
    private Button registerBtn;
    @FXML
    private Button animalRegBtn;
    @FXML
    private Button appointmentBtn;
    @FXML
    private Button appointmentInfoBtn;
    @FXML
    private Button procedureInfoBtn;
    @FXML
    private Button complAppointmentBtn;
    @FXML
    private Button procedureRegBtn;

    public  static int empId;

    public  static String name = "";
    public  static String post = "";
    public  static String specialization = "";

    @Override
    public void initialize(URL location, ResourceBundle resources) {
       File file= new File("src/img/" + name.split(" ")[0] + ".jpeg");
        Image image = new Image(file.toURI().toString());
        photo.setImage(image);
        textHi.setText("Здравствуйте, "+name+" !");
        if(!specialization.isEmpty()){
        doljnost.setText("Ваша должность: "+post+", "+specialization);
        }else {
            doljnost.setText("Ваша должность: "+post);
        }

        if(post.equals("Администратор")){
            complAppointmentBtn.setDisable(true);
            complAppointmentBtn.setVisible(false);
            procedureRegBtn.setDisable(true);
            procedureRegBtn.setVisible(false);
        }else {
            registerBtn.setDisable(true);
            registerBtn.setVisible(false);
            appointmentBtn.setDisable(true);
            appointmentBtn.setVisible(false);
            appointmentInfoBtn.setDisable(true);
            appointmentInfoBtn.setVisible(false);
        }
    }

    public void exit(ActionEvent event) throws IOException {
        Stage st3 = new Stage();

        Parent root = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("hello-view.fxml")));
        st3.getIcons().add(new Image("logo.png"));
        st3.setTitle("ComfyDent");
        st3.setScene(new Scene(root, 320, 240));
        st3.setResizable(false);
        st3.show();

        ((Node)(event.getSource())).getScene().getWindow().hide();
    }

    public void clientRegister(ActionEvent event) throws IOException {
        Stage register = new Stage();
        Parent parent = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("registration.fxml")));
        register.getIcons().add(new Image("logo.png"));
        register.setTitle("Регистрация клиента");
        register.setScene(new Scene(parent, 250, 300));
        register.setResizable(false);
        register.show();
    }

    public void appointmentRegister(ActionEvent event) throws IOException {
        Stage appointment = new Stage();
        Parent parent = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("appointmentRegister.fxml")));
        appointment.getIcons().add(new Image("logo.png"));
        appointment.setTitle("Запись на прием");
        appointment.setScene(new Scene(parent, 400, 400));
        appointment.setResizable(false);
        appointment.show();
    }

    public void appointmentInfo(ActionEvent event) throws IOException {
        Stage animalRegister = new Stage();
        Parent parent = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("appointmentInfo.fxml")));
        animalRegister.getIcons().add(new Image("logo.png"));
        animalRegister.setTitle("Информация о приемах");
        animalRegister.setScene(new Scene(parent, 1000, 400));
        animalRegister.setResizable(false);
        animalRegister.show();
    }

    public void procedureInfo(ActionEvent event) throws IOException {
        Stage animalRegister = new Stage();
        Parent parent = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("procedureInfo.fxml")));
        animalRegister.getIcons().add(new Image("logo.png"));
        animalRegister.setTitle("Информация о процедурах");
        animalRegister.setScene(new Scene(parent, 800, 400));
        animalRegister.setResizable(false);
        animalRegister.show();
    }

    public void appointmentCompl(ActionEvent event) throws IOException {
        Stage appointment = new Stage();
        Parent parent = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("appointmentCompl.fxml")));
        appointment.getIcons().add(new Image("logo.png"));
        appointment.setTitle("ComfyDent");
        appointment.setScene(new Scene(parent, 400, 400));
        appointment.setResizable(false);
        appointment.show();
    }

    public void procedureRegister(ActionEvent event) throws IOException {
        Stage appointment = new Stage();
        Parent parent = FXMLLoader.load(Objects.requireNonNull(getClass().getResource("procedureRegister.fxml")));
        appointment.getIcons().add(new Image("logo.png"));
        appointment.setTitle("Запись на процедуры");
        appointment.setScene(new Scene(parent, 400, 400));
        appointment.setResizable(false);
        appointment.show();
    }
}
