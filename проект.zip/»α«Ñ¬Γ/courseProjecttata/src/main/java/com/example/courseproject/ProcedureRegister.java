package com.example.courseproject;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.paint.Color;

import java.net.URL;
import java.sql.*;
import java.util.ResourceBundle;

import static com.example.courseproject.DB.*;

public class ProcedureRegister implements Initializable {

    @FXML
    private ComboBox animalField;
    @FXML
    private TextField dateField;
    @FXML
    private TextField procedureField;
    @FXML
    private Label label;
    private String buffer = "";
    String[]arr = new String[4];

    private String client = "";
    private String date = "";
    private String procedure = "";

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet resultSet = null;
        try {
            connection = DriverManager.getConnection(DATABASE_URL, DATABASE_USERNAME, DATABASE_PASSWORD);
            preparedStatement = connection.prepareStatement("SELECT concat(client_id,\", ФИО: \", client_name) FROM clients;");
            resultSet = preparedStatement.executeQuery();
            while (resultSet.next()){
                animalField.getItems().add(resultSet.getString(1));
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

    }

    public void procedureRegistration() throws SQLException {
        buffer = animalField.getValue().toString();
        arr = buffer.split(",");
        client = arr[0];
        date=dateField.getText();
        procedure=procedureField.getText();
        Connection connection = DriverManager.getConnection(DATABASE_URL, DATABASE_USERNAME, DATABASE_PASSWORD);
        PreparedStatement preparedStatement = connection.prepareStatement("insert into procedures(employee_employee_id," +
                " client_id, date, procedure_type) values(?, ?, ?, ?)");
        preparedStatement.setInt(1, Profile.empId);
        preparedStatement.setString(2, client);
        preparedStatement.setString(3, date);
        preparedStatement.setString(4, procedure);
        try {
            preparedStatement.executeUpdate();
        } catch (SQLException e) {
            label.setTextFill(Color.web("#ff0000"));
            label.setText("Ошибка");
            throw new RuntimeException(e);
        }
        label.setTextFill(Color.web("#000"));
        label.setText("Запись прошла успешно");
    }

}
