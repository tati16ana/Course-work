-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 22, 2022 at 05:01 PM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `comfydent`
--

-- --------------------------------------------------------

--
-- Table structure for table `appointment`
--

CREATE TABLE `appointment` (
  `appointment_id` int(11) NOT NULL,
  `employee_employee_id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `date` date DEFAULT NULL,
  `complaint` varchar(45) DEFAULT NULL,
  `diagnosis` varchar(45) DEFAULT NULL,
  `therapy` varchar(45) DEFAULT NULL,
  `cost` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `appointment`
--

INSERT INTO `appointment` (`appointment_id`, `employee_employee_id`, `client_id`, `date`, `complaint`, `diagnosis`, `therapy`, `cost`) VALUES
(1, 2, 3, '2022-10-01', 'Боль в правой верхней челюсти при нажатии', 'Кариозное поражение 1-го моляра', 'Лечение кариеса и прием новокаина 1 раз в теч', 2000),
(2, 3, 1, '2022-09-01', 'Логонивроз после перенесееной травмы челюстно', 'Искривление верхнего челюстного отдела ', 'Установка брекет-систем и дальнейшее использо', 14800),
(3, 4, 2, '2022-08-01', 'Боль в нижней правой челюсти', 'Пародонтит', 'Удаление 2-го моляра и прием ледокаина 2 раза', 6300),
(24, 3, 2, '2022-11-22', 'Боль', 'Пародонтит', 'Лекарства', 4000),
(25, 3, 5, '2022-11-11', 'Боль', NULL, NULL, NULL),
(26, 3, 1, '2022-11-23', 'Кариес', NULL, NULL, NULL),
(27, 3, 1, '2022-11-23', 'Кариес', NULL, NULL, NULL),
(28, 2, 2, '2022-11-23', 'Осмотр', '<jkm', 'bbbb', 666),
(29, 2, 7, '2022-11-23', 'Воспаление десны верхней челюсти', NULL, NULL, NULL),
(30, 2, 7, '2022-11-23', 'Воспаление десны у 3-го моляра', NULL, NULL, NULL),
(31, 2, 7, '2022-11-21', 'Боль в правой нижней челюсти', 'Пародонтит', 'Обезбол. 2 раза в день в течение 5-ти дней', 3400),
(32, 2, 7, '2022-11-20', 'Воспаление десен', 'Кариес', 'Удаление кариеса', 2200);

-- --------------------------------------------------------

--
-- Table structure for table `clients`
--

CREATE TABLE `clients` (
  `client_id` int(11) NOT NULL,
  `client_name` varchar(45) DEFAULT NULL,
  `phone_number` varchar(20) DEFAULT NULL,
  `date_of_birth` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `clients`
--

INSERT INTO `clients` (`client_id`, `client_name`, `phone_number`, `date_of_birth`) VALUES
(1, 'Ирисов Петр Дмитриевич', '89200016578', '1999-07-13'),
(2, 'Самойлова Румия Игнатьевна', '89205437899', '1961-12-24'),
(3, 'Виноградов Роман Михайлович', '89200345655', '1988-01-08'),
(5, 'Кошкина', '89050005522', '2000-12-12'),
(6, 'Антонов Ибрагим Степанович', '89200986754', '2001-09-12'),
(7, 'Степанов Игорь Максимов', '89200345678', '1999-12-10'),
(8, 'Иванов Иван Петрович', '89108090367', '1988-01-01');

-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE `employee` (
  `employee_id` int(11) NOT NULL,
  `post` varchar(45) DEFAULT NULL,
  `specialization` varchar(45) DEFAULT NULL,
  `name` varchar(45) DEFAULT NULL,
  `login` varchar(45) DEFAULT NULL,
  `password` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`employee_id`, `post`, `specialization`, `name`, `login`, `password`) VALUES
(1, 'Администратор', '', 'Иванова Юлия Викторовна', 'ivanova', '123'),
(2, 'Врач', 'Стоматолог-терапевт', 'Мартемьянов Артур Рустемович', 'mart', '234'),
(3, 'Врач', 'Стоматолог-ортодонт', 'Лаврова Ирина Денисовна', 'lavrov', '345'),
(4, 'Врач', 'Стоматолог-хирург', 'Бугров Кирил Александрович', 'bygr', '456');

-- --------------------------------------------------------

--
-- Table structure for table `procedures`
--

CREATE TABLE `procedures` (
  `procedure_id` int(11) NOT NULL,
  `employee_employee_id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `date` datetime DEFAULT NULL,
  `procedure_type` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `procedures`
--

INSERT INTO `procedures` (`procedure_id`, `employee_employee_id`, `client_id`, `date`, `procedure_type`) VALUES
(1, 3, 1, '2022-11-05 12:30:00', 'Установка брекет систем'),
(2, 4, 2, '2022-10-04 16:00:00', 'Удаление зуба'),
(4, 2, 3, '2022-09-03 00:00:00', 'Лечение кариеса'),
(5, 2, 3, '2000-08-04 00:00:00', 'Снимок'),
(6, 2, 7, '2022-11-25 00:00:00', 'Снимок полости рта'),
(7, 2, 7, '2022-11-25 00:00:00', 'Снимок полости рта');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `appointment`
--
ALTER TABLE `appointment`
  ADD PRIMARY KEY (`appointment_id`,`employee_employee_id`),
  ADD KEY `fk_employee_has_animal_passport_employee1` (`employee_employee_id`),
  ADD KEY `client_id` (`client_id`);

--
-- Indexes for table `clients`
--
ALTER TABLE `clients`
  ADD PRIMARY KEY (`client_id`);

--
-- Indexes for table `employee`
--
ALTER TABLE `employee`
  ADD PRIMARY KEY (`employee_id`);

--
-- Indexes for table `procedures`
--
ALTER TABLE `procedures`
  ADD PRIMARY KEY (`procedure_id`,`employee_employee_id`),
  ADD KEY `fk_employee_has_animal_passport_employee2` (`employee_employee_id`),
  ADD KEY `client_id` (`client_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `appointment`
--
ALTER TABLE `appointment`
  MODIFY `appointment_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `clients`
--
ALTER TABLE `clients`
  MODIFY `client_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `procedures`
--
ALTER TABLE `procedures`
  MODIFY `procedure_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `appointment`
--
ALTER TABLE `appointment`
  ADD CONSTRAINT `appointment_ibfk_1` FOREIGN KEY (`client_id`) REFERENCES `clients` (`client_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_employee_has_animal_passport_employee1` FOREIGN KEY (`employee_employee_id`) REFERENCES `employee` (`employee_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Constraints for table `procedures`
--
ALTER TABLE `procedures`
  ADD CONSTRAINT `fk_employee_has_animal_passport_employee2` FOREIGN KEY (`employee_employee_id`) REFERENCES `employee` (`employee_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `procedures_ibfk_1` FOREIGN KEY (`client_id`) REFERENCES `clients` (`client_id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
